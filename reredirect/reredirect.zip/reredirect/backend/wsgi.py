from back import app, start_background_thread

start_background_thread()

application = app